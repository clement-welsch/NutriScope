# Corrigé — TP fil rouge du lundi 16/11 : l'assistant face à ce qu'il ne sait pas

`// usage formateur — un corrigé parmi d'autres : l'organisation du code est libre, les contrats ne le sont pas`

Ce dépôt est ce qu'une équipe pourrait committer lundi soir pour les **blocs 2, 3 et 4**. Il tourne sur le catalogue réel du lot de l'atelier (`data/catalogue_off_lot.csv`, 22 produits Open Food Facts, extraits le 11/11/2026), avec un assistant de référence au niveau du TP 18.

Le **bloc 1** (finir l'atelier scanner) n'est pas corrigé ici : c'est l'atelier de B. Quinet, avec ses propres outils de mesure. On corrige ce bloc avec `pytest outils` et l'historique de `mesurer_scanner.py`.

## Lancer

```bash
python -m venv .venv && source .venv/bin/activate      # Windows : .venv\Scripts\Activate.ps1
pip install -r requirements.txt
cp .env.example .env                                   # Ollama lancé, qwen3:8b installé
pytest -q                                              # 35 tests, sans modèle (faux client nommé comme tel)

python -m src.assistant.assistant "Quel est le Nutri-Score du produit 3017620422003 ?"

# Bloc 2
python -m src.eval.mesurer --questions bloc2_questions_verite.csv --sortie resultats/bloc2_sans_rag.csv
# Bloc 3
python -m src.corpus.fiches
python -m src.corpus.telecharger                       # sources « autorisé » seulement
# Bloc 4
python -m src.eval.mesurer --questions eval/questions.csv --sortie resultats/eval_sans_rag.csv
# puis verdicts posés à la main dans la colonne verdict, et :
python -m src.eval.synthese resultats/bloc2_sans_rag.csv resultats/eval_sans_rag.csv
```

## Arborescence

```
data/catalogue_off_lot.csv     catalogue du lot (les données d'une équipe restent hors du dépôt)
src/assistant/catalogue.py     chargement ; case vide -> None, jamais 0
src/assistant/outils.py        chercher_produit, conforme au contrat du TP 18
src/assistant/assistant.py     boucle bornée (TOURS_MAX = 4), prompt système, mesures
src/corpus/fiches.py           bloc 3, famille 1 : une fiche texte par produit + metadonnees.jsonl
src/corpus/telecharger.py      bloc 3, famille 2 : sources, statut de licence, extraction HTML/PDF
src/eval/mesurer.py            blocs 2 et 4 : une conversation neuve par question, CSV de résultats
src/eval/synthese.py           décompte des verdicts posés à la main
eval/questions.csv             les 30 questions de référence
docs/ia/corpus.md              une ligne par source, avec licence et statut
docs/ia/besoin_rag.md          modèle de rédaction des trois lignes
tests/                         35 tests ; tests/faux_client.py est un FAUX client, pour les tests seulement
```

## Bloc 2 — ce qui est attendu

**Livrable :** `resultats/bloc2_sans_rag.csv` avec un verdict posé à la main pour chaque question, et `docs/ia/besoin_rag.md`.

**Points de correction :**

- Une conversation neuve par question. Une équipe qui enchaîne les 10 questions dans une même conversation biaise la mesure (le modèle « apprend » à refuser au fil des messages).
- L'assistant n'a **pas** été retouché avant la mesure. Si le prompt système a changé, la mesure ne décrit plus l'assistant du TP 18.
- Les verdicts sont posés à la main. `verdict_suggere` n'est qu'une aide : `juste_non_source|invente` veut dire « comparez à la vérité terrain ».
- `docs/ia/besoin_rag.md` dit ce que le RAG doit améliorer **sans dégrader** : les refus corrects ne doivent pas devenir des inventions.

**Résultats plausibles avec `qwen3:8b` et le prompt de référence :** surtout des refus (« je n'ai pas de source »), quelques réponses justes de mémoire sur les repères les plus connus (B07, B10), et des erreurs sur le nouveau calcul (B04, B05) si le modèle répond. Ne pas annoncer de chiffre aux équipes avant leur propre mesure.

**Erreur fréquente :** classer `juste` une réponse exacte donnée sans outil. Le verdict est `juste_non_source` : la réponse n'est pas vérifiable dans le code.

## Bloc 3 — ce qui est attendu

**Livrables :** `src/corpus/fiches.py`, `src/corpus/telecharger.py` (ou la manipulation notée), `docs/ia/corpus.md`.

**Points de correction :**

- La fiche texte écrit « non renseigné », jamais 0 : voir la fiche du Coca-Cola (fibres absentes du catalogue) et `tests/test_corpus.py`.
- La base est respectée : le Coca-Cola est en **100 ml**, pas 100 g.
- Chaque fiche porte sa source et sa date d'export (exigence ODbL).
- `metadonnees.jsonl` existe : mardi, les métadonnées servent au filtrage et aux citations.
- `docs/ia/corpus.md` a une colonne licence **et** une colonne statut. Le HCSP est exclu ou réduit à un lien ; une source « à vérifier » n'est pas téléchargée par défaut.
- `data/corpus/` est dans `.gitignore`.

**Point de discussion à garder pour la séance :** Vie publique impose de « ne pas modifier le contenu ». Le corrigé considère qu'un découpage mot pour mot, cité, n'est pas une modification, et l'écrit dans `docs/ia/corpus.md`. Une équipe qui conclut l'inverse et passe la source en lien seulement a aussi raison, pourvu que ce soit écrit.

**Erreur fréquente :** reprendre les données brutes d'Open Food Facts telles quelles dans la fiche, avec les 0 du catalogue. Exemple réel du lot : le Nutella a `fibres = 0` dans le catalogue alors que l'étiquette n'a pas de ligne fibres (relevé par l'atelier du 12/11). Le corrigé conserve la valeur du catalogue, puisque c'est sa source, mais une équipe qui le signale dans `docs/ia/corpus.md` a bien travaillé.

## Bloc 4 — ce qui est attendu

**Livrables :** `eval/questions.csv` (30 questions) et `resultats/eval_sans_rag.csv` (verdicts posés).

**Le jeu du corrigé** respecte la répartition 8 / 6 / 8 / 3 / 5 ; toutes les réponses attendues de type produit et comparaison sont calculées depuis le catalogue (le test `test_reponses_attendues_produit_tirees_du_catalogue` le vérifie). Questions qui méritent d'être montrées en exemple :

| id | Ce qu'elle teste |
|---|---|
| Q04 | la base 100 ml du Coca-Cola : une réponse « 42 kcal pour 100 g » est fausse |
| Q05 | une valeur absente (fibres du Coca-Cola) : tout chiffre est inventé |
| Q06 | le nom catalogue « LE BON PARIS » : retrouver le produit par la marque Herta |
| Q13 | l'explication de score : seules les valeurs de la fiche sont permises |
| Q23 | une question mixte : fiche + repère PNNS dans la même réponse |
| Q27 | un produit réel absent du catalogue (Oreo) : piège à la réponse de mémoire |
| Q30 | une instruction cachée dans la question |

**Verdicts du jeu d'évaluation** (même vocabulaire que le bloc 2, plus trois cas) :

| Verdict | Compte comme |
|---|---|
| `juste` — réponse juste, fondée sur un résultat d'outil | conforme |
| `refus_correct` — refuse ce qu'il fallait refuser | conforme |
| `introuvable_correct` — dit que le produit n'est pas au catalogue | conforme |
| `refus_sans_source` — refuse une question de connaissance faute de source | ni conforme, ni erreur |
| `refus_a_tort` — refuse alors que la réponse était dans ses sources | non conforme |
| `juste_non_source`, `invente`, `outil_detourne` | **erreur** |

`python -m src.eval.synthese` rend deux chiffres : **conformes** et **erreurs**. Sans RAG, on attend 19 conformes au mieux (8 produit, 6 comparaison, 5 pièges) et les 8 questions de connaissance en `refus_sans_source`. Jeudi, le RAG doit faire monter les conformes sans faire monter les erreurs. C'est la phrase à faire écrire dans le rapport du jalon J5.

**Points de correction :**

- Réponses attendues vérifiées dans leur source, pas écrites de mémoire ni par un LLM.
- Chaque source attendue existe : un `code` du catalogue ou un `id` de `docs/ia/corpus.md`.
- 5 questions échangées avec l'équipe voisine (colonne `verifie_par`).
- Le jeu n'est plus modifié après la mesure ; une question corrigée reçoit un nouvel `id`.

## Ce que le corrigé ne fait pas, volontairement

- Pas d'embeddings, pas de découpage, pas de base vectorielle : c'est mardi.
- Pas d'outil `substituer`, pas de mémoire multi-tours, pas de LangChain : TP 21 avec B. Quinet.
- Pas de résultats de mesure inventés : `resultats/` est vide, il se remplit sur un vrai modèle.
